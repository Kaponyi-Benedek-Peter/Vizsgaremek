import { Component } from '@angular/core';

@Component({
  selector: 'app-newsletter-form',
  imports: [],
  templateUrl: './newsletter-form.html',
  styleUrl: './newsletter-form.css',
})
export class NewsletterForm {

}
