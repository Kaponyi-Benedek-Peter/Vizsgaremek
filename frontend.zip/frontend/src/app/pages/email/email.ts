import { Component } from '@angular/core';

@Component({
  selector: 'app-email',
  imports: [],
  templateUrl: './email.html',
  styleUrl: './email.css',
})
export class Email {

}
