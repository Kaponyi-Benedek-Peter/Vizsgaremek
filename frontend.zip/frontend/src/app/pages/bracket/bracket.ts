import { Component } from '@angular/core';

@Component({
  selector: 'app-bracket',
  imports: [],
  templateUrl: './bracket.html',
  styleUrl: './bracket.css',
})
export class Bracket {

}
