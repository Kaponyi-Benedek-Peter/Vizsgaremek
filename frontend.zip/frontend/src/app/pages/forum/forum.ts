import { Component } from '@angular/core';

@Component({
  selector: 'app-forum',
  imports: [],
  templateUrl: './forum.html',
  styleUrl: './forum.css',
})
export class Forum {

}
