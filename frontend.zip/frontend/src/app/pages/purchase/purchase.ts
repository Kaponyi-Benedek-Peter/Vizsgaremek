import { Component } from '@angular/core';

@Component({
  selector: 'app-purchase',
  imports: [],
  templateUrl: './purchase.html',
  styleUrl: './purchase.css',
})
export class Purchase {

}
